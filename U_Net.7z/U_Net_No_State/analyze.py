import torch
import torch.nn as nn
import os
import numpy as np
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
from UNet import UNet



# load data
cur_dir = os.getcwd()
data_dir = cur_dir + '/../../data/'
data = np.load(data_dir + 'stokes_triangle_1000.npz')

# os.mkdir(cur_dir + '/run_1/')
base_dir = cur_dir + '/run_1/'

# swap the axes
sdfs = data['sdf']
sdfs = np.swapaxes(sdfs,0,2)
vx   = data['vx']
vx = np.swapaxes(vx,0,2)
vy   = data['vy']
vy = np.swapaxes(vy,0,2)
rho  = data['rho']
rho = np.swapaxes(rho,0,2)

# scale the data
sdf_scaler = StandardScaler()
vx_scaler  = StandardScaler()
vy_scaler  = StandardScaler()
rho_scaler = StandardScaler()

sdf_scaler.fit(sdfs.reshape((-1,1)))
vx_scaler.fit(vx.reshape((-1,1)))
vy_scaler.fit(vy.reshape((-1,1)))
rho_scaler.fit(rho.reshape((-1,1)))

sdfs_scaled = np.reshape((sdf_scaler.transform(sdfs.reshape((-1,1)))),sdfs.shape)
vx_scaled = np.reshape((vx_scaler.transform(vx.reshape((-1,1)))),vx.shape)
vy_scaled = np.reshape((vy_scaler.transform(vy.reshape((-1,1)))),vy.shape)
rho_scaled = np.reshape((rho_scaler.transform(rho.reshape((-1,1)))),rho.shape)

# convert to torch
torch_sdf = torch.from_numpy(sdfs_scaled).float()
torch_vx  = torch.from_numpy(vx_scaled).float()
torch_vy  = torch.from_numpy(vy_scaled).float()
torch_rho = torch.from_numpy(rho_scaled).float()

torch_sdf = torch.from_numpy(sdfs_scaled).float()
torch_sdf = torch_sdf.unsqueeze(1)
torch_vx  = torch.from_numpy(vx_scaled).float()
torch_vy  = torch.from_numpy(vy_scaled).float()
torch_rho = torch.from_numpy(rho_scaled).float()

Y = torch.stack((torch_vx,torch_vy),dim=1)


torch.set_grad_enabled(False)
model = UNet(n_channels = 1,n_classes = 2,bilinear=True)

run_data = torch.load(base_dir + 'run_1.pt',map_location = torch.device('cpu'))
model.load_state_dict(run_data['model'])


def disp_plots(true, out, title = ""):
    ''' Function to plot and save the true and generated velocity fields'''
    true_np = true.cpu().detach().numpy()
    out_np = out.cpu().detach().numpy()
    
    fig, axs = plt.subplots(2, 2, constrained_layout=True)
    fig.suptitle(title)
    axs[0,0].imshow(true_np[0,0,:,:])
    axs[0,0].set_title("X velocities ground truth")
    
    axs[0,1].imshow(out_np[0,0,:,:])
    axs[0,1].set_title("X velocities model output")
    
    axs[1,0].imshow(true_np[0,1,:,:])
    axs[1,0].set_title("Y velocities ground truth")
    
    axs[1,1].imshow(out_np[0,1,:,:])
    axs[1,1].set_title("Y velocities model output")
    plt.show()
    
    # filename = title.replace(' ', '_').lower() + '.png'
    # fig.savefig(filename)


for i in range(10):

  out = model.forward(torch_sdf[i].view(1,1,torch_sdf[i].shape[1],torch_sdf[i].shape[2]))
  disp_plots(Y[i].view(1,2,64,128),out)


tr_loss = run_data['tr_loss']
val_loss = run_data['val_loss']
plt.figure(figsize=(10,10))
plt.plot([i*32/800 for i in range(len(tr_loss))],tr_loss)
plt.plot([i*32/200 for i in range(len(val_loss))],val_loss)
plt.title('Loss By Epoch')
plt.xlabel('Loss')
plt.ylabel('Epochs')
plt.yscale('log')
plt.legend(['Training','Validation'])
plt.plot()