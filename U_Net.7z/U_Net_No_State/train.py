import torch
import torch.nn as nn
import os
import numpy as np
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
from UNet import UNet


# load data
cur_dir = os.getcwd()
data_dir = cur_dir + '/../../data/'
data = np.load(data_dir + 'stokes_triangle_1000.npz')

# os.mkdir(cur_dir + '/run_1/')
base_dir = cur_dir + '/run_1/'

# swap the axes
sdfs = data['sdf']
sdfs = np.swapaxes(sdfs,0,2)
vx   = data['vx']
vx = np.swapaxes(vx,0,2)
vy   = data['vy']
vy = np.swapaxes(vy,0,2)
rho  = data['rho']
rho = np.swapaxes(rho,0,2)

# scale the data
sdf_scaler = StandardScaler()
vx_scaler  = StandardScaler()
vy_scaler  = StandardScaler()
rho_scaler = StandardScaler()

sdf_scaler.fit(sdfs.reshape((-1,1)))
vx_scaler.fit(vx.reshape((-1,1)))
vy_scaler.fit(vy.reshape((-1,1)))
rho_scaler.fit(rho.reshape((-1,1)))

sdfs_scaled = np.reshape((sdf_scaler.transform(sdfs.reshape((-1,1)))),sdfs.shape)
vx_scaled = np.reshape((vx_scaler.transform(vx.reshape((-1,1)))),vx.shape)
vy_scaled = np.reshape((vy_scaler.transform(vy.reshape((-1,1)))),vy.shape)
rho_scaled = np.reshape((rho_scaler.transform(rho.reshape((-1,1)))),rho.shape)

# convert to torch
torch_sdf = torch.from_numpy(sdfs_scaled).float()
torch_vx  = torch.from_numpy(vx_scaled).float()
torch_vy  = torch.from_numpy(vy_scaled).float()
torch_rho = torch.from_numpy(rho_scaled).float()

# munge the input
tr_input = torch.unsqueeze(torch_sdf,dim=1)
output = torch.stack((torch_vx,torch_vy),dim=1)
output.shape


data_set = torch.utils.data.TensorDataset(tr_input,output)
# split data set
train_set,val_set = torch.utils.data.dataset.random_split(data_set,(800,200))

# dataloaders
tr_loader = torch.utils.data.DataLoader(train_set)
val_loader = torch.utils.data.DataLoader(val_set)



def train_net(tr_set,val_set,lr,epochs=1000,val_split=.2,
              n_channels = 1, n_classes = 2,batch_size=32):
  tr_loss_vec = []
  val_loss_vec = []

  loss  = nn.MSELoss()
  model = UNet(n_channels = n_channels,n_classes = 2,bilinear=True)
  model.cuda()
  model.float()
  optim = torch.optim.Adam(model.parameters(),lr=lr)

  tr_loader = torch.utils.data.DataLoader(tr_set,batch_size = batch_size,
                                          shuffle=True,pin_memory = True)
  val_loader = torch.utils.data.DataLoader(val_set,batch_size = batch_size,
                                          shuffle=True,pin_memory = True)

  best_loss = 100
  for i in range(epochs):
    print('epoch: ',i)
    torch.set_grad_enabled(True)
    model.train()

    for idx,(data) in enumerate(tr_loader):
      x = data[0].cuda()
      y = data[1].cuda()
      out = model(x)
      sample_loss = loss(out,y)
      tr_loss_vec.extend([sample_loss.cpu().detach().numpy()])
      sample_loss.backward()
      optim.step()
      optim.zero_grad()

      if idx%10 == 0:
        print(idx/len(tr_loader)*100)

    if val_split is not 0:
      torch.set_grad_enabled(False)
      model.eval()

      for v_idx,(v_data) in enumerate(val_loader):
        x = v_data[0].cuda()
        y = v_data[1].cuda()
        out = model(x)
        sample_loss = loss(out,y)
        val_loss_vec.extend([sample_loss.cpu().detach().numpy()])

    if i > 400:
      if np.mean(val_loss_vec[-200:]) < best_loss:
        best_loss = np.mean(val_loss_vec[-200:])
      else:
        print('training stagnated, exiting')
        break

  hyp_dict = {}
  hyp_dict['tr_loss']  = tr_loss_vec
  hyp_dict['val_loss'] = val_loss_vec
  hyp_dict['n_epochs'] = i
  hyp_dict['lr']       = lr
  hyp_dict['batch_size'] = batch_size
  hyp_dict['n_channels'] = n_channels
  hyp_dict['model'] = model.state_dict()
  torch.save(hyp_dict,base_dir+'run_1'+'.pt')
  
  return hyp_dict



hd = train_net(train_set,val_set,lr=.001,epochs=1000,val_split=.2,
              n_channels = 1, n_classes = 2,batch_size=32)